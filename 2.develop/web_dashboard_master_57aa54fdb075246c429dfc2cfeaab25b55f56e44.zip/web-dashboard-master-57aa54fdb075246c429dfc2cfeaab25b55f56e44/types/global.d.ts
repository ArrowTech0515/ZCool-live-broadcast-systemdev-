declare global {
  interface Window {
    __APP_CONFIG__: any
  }
}
export {}
