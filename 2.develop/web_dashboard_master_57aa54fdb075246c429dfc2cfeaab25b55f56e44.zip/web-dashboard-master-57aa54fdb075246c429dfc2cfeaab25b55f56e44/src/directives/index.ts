import type { App } from 'vue'

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export default (app: App) => {
  // 这里注册指令
}
