<template>
  <h1>anchor statistics</h1>
</template>
