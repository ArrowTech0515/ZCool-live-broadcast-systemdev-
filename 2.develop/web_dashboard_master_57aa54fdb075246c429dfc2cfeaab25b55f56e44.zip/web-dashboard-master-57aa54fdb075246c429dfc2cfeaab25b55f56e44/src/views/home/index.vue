<script setup>

</script>

<template>
  <h1>欢迎登录站酷平台</h1>
</template>

<script setup>
</script>

<style lang="sass" scoped>

</style>
