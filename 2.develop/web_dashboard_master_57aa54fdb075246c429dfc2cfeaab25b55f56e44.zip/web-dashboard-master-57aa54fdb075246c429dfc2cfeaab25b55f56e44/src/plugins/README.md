# 插件

第三方插件，如果是全局的插件，可以在`/src/plugins/index.ts`进行注册，在`/src/main.ts`中进行全局注册。
