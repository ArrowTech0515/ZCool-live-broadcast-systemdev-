// 性别
export const SEX = {
  1: '男',
  2: '女',
}

// 用户状态
export const USER_STATUS = {
  0: '正常',
  1: '已锁定',
  2: '已删除',
}
