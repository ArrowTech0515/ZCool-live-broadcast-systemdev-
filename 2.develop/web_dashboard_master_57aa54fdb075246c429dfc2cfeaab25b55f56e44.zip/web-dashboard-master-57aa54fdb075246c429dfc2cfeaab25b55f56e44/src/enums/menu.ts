// 资源类型
export const RESOURCE_TYPE = {
  0: '菜单',
  1: '按钮',
}
