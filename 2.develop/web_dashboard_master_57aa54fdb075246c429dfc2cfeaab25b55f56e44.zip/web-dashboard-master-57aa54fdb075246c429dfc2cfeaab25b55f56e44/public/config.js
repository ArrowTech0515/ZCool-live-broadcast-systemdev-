// 运行时配置
window.__APP_CONFIG__ = {
  debug: true,
}
